package com.example.spss.controller;

import com.example.spss.validator.AnswerDataLoadService;
import com.example.spss.validator.AnswerDataValidator;
import com.example.spss.validator.dto.AnswerRow;
import com.example.spss.validator.dto.ValidateResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * V2 执行规则接口。
 *
 * 替换目标：页面必须请求 /api/v2/rules/execute。
 * 返回目标：data 内固定包含 passedList / failedList，页面据此分两块展示。
 */
@RestController
@RequestMapping("/api/v2/rules")
public class SpssRuleExecuteController {

    @Autowired
    private AnswerDataLoadService answerDataLoadService;

    @Autowired
    private AnswerDataValidator answerDataValidator;

    @PostMapping("/execute")
    public AjaxResult execute(@RequestParam(value = "scriptId", required = false) Long scriptId,
                              @RequestParam(value = "tableId", required = false) Long tableId,
                              @RequestParam(value = "projectId", required = false) Long projectId,
                              @RequestParam(value = "year", required = false) String year,
                              @RequestParam(value = "csvFile", required = false) MultipartFile csvFile,
                              @RequestParam(value = "mappingFile", required = false) MultipartFile mappingFile,
                              @RequestParam(value = "studentFile", required = false) MultipartFile studentFile,
                              @RequestParam(value = "fieldCheck", required = false) String fieldCheck) {
        try {
            if (tableId == null) {
                return AjaxResult.error("tableId不能为空");
            }
            if (projectId == null) {
                return AjaxResult.error("projectId不能为空");
            }
            if (!StringUtils.hasText(year)) {
                return AjaxResult.error("year不能为空");
            }
            if (csvFile == null || csvFile.isEmpty()) {
                return AjaxResult.error("CSV文件不能为空");
            }

            List<AnswerRow> rows = answerDataLoadService.loadFromCsv(csvFile, tableId, projectId, year);
            ValidateResult validateResult = answerDataValidator.validate(rows);

            // 关键：不要再返回旧 fieldErrors/warnCount 结构。
            return AjaxResult.success(validateResult);
        } catch (Exception e) {
            return AjaxResult.error("执行失败：" + e.getMessage());
        }
    }
}
