package com.example.spss.controller;

import com.example.spss.common.ApiResponse;
import com.example.spss.validator.AnswerDataLoadService;
import com.example.spss.validator.AnswerDataValidator;
import com.example.spss.validator.AnswerDataRow;
import com.example.spss.validator.dto.ValidateResult;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * V2 执行规则接口。
 *
 * 页面统一调用：POST /api/v2/rules/execute
 */
@RestController
@RequestMapping("/api/v2/rules")
public class RuleExecuteV2Controller {

    private final AnswerDataLoadService answerDataLoadService;
    private final AnswerDataValidator answerDataValidator;

    public RuleExecuteV2Controller(AnswerDataLoadService answerDataLoadService,
                                   AnswerDataValidator answerDataValidator) {
        this.answerDataLoadService = answerDataLoadService;
        this.answerDataValidator = answerDataValidator;
    }

    @PostMapping(value = "/execute", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ApiResponse<ValidateResult> execute(@RequestParam(value = "csvFile", required = false) MultipartFile csvFile,
                                               @RequestParam(value = "file", required = false) MultipartFile file,
                                               @RequestParam(value = "scriptId", required = false) Long scriptId,
                                               @RequestParam(value = "tableId", required = false) Long tableId,
                                               @RequestParam(value = "table_id", required = false) Long tableId2,
                                               @RequestParam(value = "projectId", required = false) Long projectId,
                                               @RequestParam(value = "project_id", required = false) Long projectId2,
                                               @RequestParam(value = "year", required = false) String year,
                                               @RequestParam(value = "fieldCheck", required = false) String fieldCheck) {
        try {
            MultipartFile actualFile = csvFile != null ? csvFile : file;
            Long actualTableId = tableId != null ? tableId : tableId2;
            Long actualProjectId = projectId != null ? projectId : projectId2;

            if (actualFile == null || actualFile.isEmpty()) {
                return ApiResponse.error(400, "请上传CSV数据文件");
            }

            @SuppressWarnings("unchecked")
            List<AnswerDataRow> rows = answerDataLoadService.loadFromCsv(actualFile, actualTableId, actualProjectId, year);
            ValidateResult validateResult = answerDataValidator.validate(rows, actualTableId, actualProjectId, year);
            return ApiResponse.success(validateResult);
        } catch (Exception e) {
            return ApiResponse.error(500, "执行规则失败：" + e.getMessage());
        }
    }
}
