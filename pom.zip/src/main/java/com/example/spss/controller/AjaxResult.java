package com.example.spss.controller;

import java.util.HashMap;

/**
 * 示例 AjaxResult。
 * 如果项目已有 AjaxResult/R，请删除本类，改用项目自带返回模型。
 */
public class AjaxResult extends HashMap<String, Object> {

    public static AjaxResult success(Object data) {
        AjaxResult result = new AjaxResult();
        result.put("code", 0);
        result.put("msg", "操作成功");
        result.put("data", data);
        return result;
    }

    public static AjaxResult error(String msg) {
        AjaxResult result = new AjaxResult();
        result.put("code", 500);
        result.put("msg", msg);
        return result;
    }
}
