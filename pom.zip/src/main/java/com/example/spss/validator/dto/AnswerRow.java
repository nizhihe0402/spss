package com.example.spss.validator.dto;

import java.io.Serializable;

/**
 * 待校验答案行。
 * 一行对应 bus_doctor_answer 或上传解析出来的一条答案。
 */
public class AnswerRow implements Serializable {

    private Long studentId;
    private String studentName;
    private Long projectId;
    private Long tableId;
    private Long questionId;
    private Long optionId;
    private String content;
    private String year;
    private String bitian;

    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public Long getProjectId() { return projectId; }
    public void setProjectId(Long projectId) { this.projectId = projectId; }

    public Long getTableId() { return tableId; }
    public void setTableId(Long tableId) { this.tableId = tableId; }

    public Long getQuestionId() { return questionId; }
    public void setQuestionId(Long questionId) { this.questionId = questionId; }

    public Long getOptionId() { return optionId; }
    public void setOptionId(Long optionId) { this.optionId = optionId; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getYear() { return year; }
    public void setYear(String year) { this.year = year; }

    public String getBitian() { return bitian; }
    public void setBitian(String bitian) { this.bitian = bitian; }
}
