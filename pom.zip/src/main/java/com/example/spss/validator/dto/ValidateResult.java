package com.example.spss.validator.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * 执行规则前的数据校验结果。
 *
 * 页面主展示只使用 passedList / failedList。
 */
public class ValidateResult {

    private int totalRows;
    private int studentCount;
    private int passedCount;
    private int failedCount;
    private List<PassedStudent> passedList = new ArrayList<PassedStudent>();
    private List<FailedStudent> failedList = new ArrayList<FailedStudent>();

    public boolean hasError() {
        return failedList != null && !failedList.isEmpty();
    }

    public int getTotalRows() {
        return totalRows;
    }

    public void setTotalRows(int totalRows) {
        this.totalRows = totalRows;
    }

    public int getStudentCount() {
        return studentCount;
    }

    public void setStudentCount(int studentCount) {
        this.studentCount = studentCount;
    }

    public int getPassedCount() {
        return passedCount;
    }

    public void setPassedCount(int passedCount) {
        this.passedCount = passedCount;
    }

    public int getFailedCount() {
        return failedCount;
    }

    public void setFailedCount(int failedCount) {
        this.failedCount = failedCount;
    }

    public List<PassedStudent> getPassedList() {
        return passedList;
    }

    public void setPassedList(List<PassedStudent> passedList) {
        this.passedList = passedList;
    }

    public List<FailedStudent> getFailedList() {
        return failedList;
    }

    public void setFailedList(List<FailedStudent> failedList) {
        this.failedList = failedList;
    }
}
