package com.example.spss.validator.dto;

/**
 * 通过校验的学生。
 */
public class PassedStudent {

    private Long studentId;
    private String studentName;

    public PassedStudent() {
    }

    public PassedStudent(Long studentId, String studentName) {
        this.studentId = studentId;
        this.studentName = studentName;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
}
