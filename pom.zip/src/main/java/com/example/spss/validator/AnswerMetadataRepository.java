package com.example.spss.validator;

import com.example.spss.validator.meta.OptionMeta;
import com.example.spss.validator.meta.QuestionMeta;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * AnswerDataValidator 需要的业务元数据查询。
 *
 * 只读访问现有表：
 * bus_table / bus_project / bus_question / bus_option / bus_student。
 */
@Repository
public class AnswerMetadataRepository {

    private final JdbcTemplate jdbcTemplate;

    public AnswerMetadataRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Set<Long> findExistingTableIds(Collection<Long> tableIds) {
        return findExistingIds("bus_table", "table_id", tableIds, true);
    }

    public Set<Long> findExistingProjectIds(Collection<Long> projectIds) {
        return findExistingIds("bus_project", "project_id", projectIds, true);
    }

    public Map<Long, QuestionMeta> findQuestionsByIds(Collection<Long> questionIds) {
        Map<Long, QuestionMeta> result = new LinkedHashMap<Long, QuestionMeta>();
        List<Long> ids = normalizeIds(questionIds);
        if (ids.isEmpty()) {
            return result;
        }

        String sql = "select question_id, table_id, content, bitian, checktype_id "
                + "from bus_question "
                + "where del_flag = '0' and question_id in (" + placeholders(ids.size()) + ")";

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, ids.toArray());
        for (Map<String, Object> row : rows) {
            QuestionMeta meta = new QuestionMeta();
            meta.setQuestionId(toLong(row.get("question_id")));
            meta.setTableId(toLong(row.get("table_id")));
            meta.setContent(toStringValue(row.get("content")));
            meta.setBitian(toStringValue(row.get("bitian")));
            meta.setChecktypeId(toLong(row.get("checktype_id")));
            if (meta.getQuestionId() != null) {
                result.put(meta.getQuestionId(), meta);
            }
        }
        return result;
    }

    public Map<Long, OptionMeta> findOptionsByIds(Collection<Long> optionIds) {
        Map<Long, OptionMeta> result = new LinkedHashMap<Long, OptionMeta>();
        List<Long> ids = normalizeIds(optionIds);
        if (ids.isEmpty()) {
            return result;
        }

        String sql = "select option_id, question_id, table_id, code, content "
                + "from bus_option "
                + "where del_flag = '0' and option_id in (" + placeholders(ids.size()) + ")";

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, ids.toArray());
        for (Map<String, Object> row : rows) {
            OptionMeta meta = new OptionMeta();
            meta.setOptionId(toLong(row.get("option_id")));
            meta.setQuestionId(toLong(row.get("question_id")));
            meta.setTableId(toLong(row.get("table_id")));
            meta.setCode(toStringValue(row.get("code")));
            meta.setContent(toStringValue(row.get("content")));
            if (meta.getOptionId() != null) {
                result.put(meta.getOptionId(), meta);
            }
        }
        return result;
    }

    public Map<Long, List<QuestionMeta>> findRequiredQuestionsByTableIds(Collection<Long> tableIds) {
        Map<Long, List<QuestionMeta>> result = new LinkedHashMap<Long, List<QuestionMeta>>();
        List<Long> ids = normalizeIds(tableIds);
        if (ids.isEmpty()) {
            return result;
        }

        String sql = "select question_id, table_id, content, bitian, checktype_id "
                + "from bus_question "
                + "where del_flag = '0' and bitian = '1' "
                + "and table_id in (" + placeholders(ids.size()) + ")";

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, ids.toArray());
        for (Map<String, Object> row : rows) {
            QuestionMeta meta = new QuestionMeta();
            meta.setQuestionId(toLong(row.get("question_id")));
            meta.setTableId(toLong(row.get("table_id")));
            meta.setContent(toStringValue(row.get("content")));
            meta.setBitian(toStringValue(row.get("bitian")));
            meta.setChecktypeId(toLong(row.get("checktype_id")));

            if (meta.getTableId() == null) {
                continue;
            }
            List<QuestionMeta> list = result.get(meta.getTableId());
            if (list == null) {
                list = new ArrayList<QuestionMeta>();
                result.put(meta.getTableId(), list);
            }
            list.add(meta);
        }
        return result;
    }

    /**
     * 尽量从 bus_student 查学生姓名。
     *
     * 不强依赖具体姓名字段名。按常见字段顺序探测：
     * student_name / name / real_name / xm。
     */
    public Map<Long, String> findStudentNames(Collection<Long> studentIds) {
        Map<Long, String> result = new HashMap<Long, String>();
        List<Long> ids = normalizeIds(studentIds);
        if (ids.isEmpty()) {
            return result;
        }

        try {
            if (!tableExists("bus_student")) {
                return result;
            }

            String nameColumn = firstExistingColumn("bus_student",
                    new String[]{"student_name", "name", "real_name", "xm", "studentName"});
            if (nameColumn == null) {
                return result;
            }

            String delFilter = columnExists("bus_student", "del_flag") ? " and del_flag = '0' " : "";
            String sql = "select student_id, `" + nameColumn + "` as student_name "
                    + "from bus_student where student_id in (" + placeholders(ids.size()) + ")" + delFilter;

            List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, ids.toArray());
            for (Map<String, Object> row : rows) {
                Long studentId = toLong(row.get("student_id"));
                String name = toStringValue(row.get("student_name"));
                if (studentId != null && !isBlank(name)) {
                    result.put(studentId, name);
                }
            }
        } catch (Exception ignored) {
            // 学生姓名不是校验必需字段。查询失败时返回空，避免阻断执行。
        }

        return result;
    }

    private Set<Long> findExistingIds(String tableName, String idColumn, Collection<Long> ids, boolean checkDelFlag) {
        Set<Long> result = new HashSet<Long>();
        List<Long> normalized = normalizeIds(ids);
        if (normalized.isEmpty()) {
            return result;
        }

        String delFilter = "";
        if (checkDelFlag && columnExists(tableName, "del_flag")) {
            delFilter = " and del_flag = '0' ";
        }

        String sql = "select `" + idColumn + "` as id from `" + tableName + "` "
                + "where `" + idColumn + "` in (" + placeholders(normalized.size()) + ")" + delFilter;
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, normalized.toArray());
        for (Map<String, Object> row : rows) {
            Long id = toLong(row.get("id"));
            if (id != null) {
                result.add(id);
            }
        }
        return result;
    }

    private boolean tableExists(String tableName) {
        try {
            Integer count = jdbcTemplate.queryForObject(
                    "select count(1) from information_schema.tables where table_schema = database() and table_name = ?",
                    new Object[]{tableName},
                    Integer.class
            );
            return count != null && count.intValue() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean columnExists(String tableName, String columnName) {
        try {
            Integer count = jdbcTemplate.queryForObject(
                    "select count(1) from information_schema.columns "
                            + "where table_schema = database() and table_name = ? and column_name = ?",
                    new Object[]{tableName, columnName},
                    Integer.class
            );
            return count != null && count.intValue() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    private String firstExistingColumn(String tableName, String[] columns) {
        if (columns == null) {
            return null;
        }
        for (String column : columns) {
            if (columnExists(tableName, column)) {
                return column;
            }
        }
        return null;
    }

    private List<Long> normalizeIds(Collection<Long> ids) {
        List<Long> list = new ArrayList<Long>();
        if (ids == null) {
            return list;
        }
        Set<Long> exists = new HashSet<Long>();
        for (Long id : ids) {
            if (id == null) {
                continue;
            }
            if (!exists.contains(id)) {
                list.add(id);
                exists.add(id);
            }
        }
        return list;
    }

    private String placeholders(int size) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append('?');
        }
        return sb.toString();
    }

    private Long toLong(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Long) {
            return (Long) value;
        }
        if (value instanceof Integer) {
            return Long.valueOf(((Integer) value).longValue());
        }
        if (value instanceof BigInteger) {
            return Long.valueOf(((BigInteger) value).longValue());
        }
        if (value instanceof Number) {
            return Long.valueOf(((Number) value).longValue());
        }
        try {
            String s = value.toString().trim();
            if (s.length() == 0) {
                return null;
            }
            return Long.valueOf(s);
        } catch (Exception e) {
            return null;
        }
    }

    private String toStringValue(Object value) {
        return value == null ? "" : String.valueOf(value).trim();
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().length() == 0;
    }
}
