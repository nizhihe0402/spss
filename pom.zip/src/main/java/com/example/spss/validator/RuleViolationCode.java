package com.example.spss.validator;

/**
 * 校验规则编码和中文名称。
 */
public enum RuleViolationCode {

    STUDENT_ID_MISSING("STUDENT_ID_MISSING", "学生ID缺失"),
    TABLE_ID_MISSING("TABLE_ID_MISSING", "表ID缺失"),
    TABLE_NOT_EXISTS("TABLE_NOT_EXISTS", "表不存在"),
    TABLE_NOT_MATCH("TABLE_NOT_MATCH", "表ID不匹配"),
    PROJECT_ID_MISSING("PROJECT_ID_MISSING", "项目ID缺失"),
    PROJECT_NOT_EXISTS("PROJECT_NOT_EXISTS", "项目不存在"),
    PROJECT_NOT_MATCH("PROJECT_NOT_MATCH", "项目ID不匹配"),
    YEAR_MISSING("YEAR_MISSING", "年份缺失"),
    YEAR_NOT_MATCH("YEAR_NOT_MATCH", "年份不匹配"),
    QUESTION_ID_MISSING("QUESTION_ID_MISSING", "问题ID缺失"),
    QUESTION_NOT_EXISTS("QUESTION_NOT_EXISTS", "问题不存在"),
    QUESTION_TABLE_NOT_MATCH("QUESTION_TABLE_NOT_MATCH", "题目与表不匹配"),
    OPTION_NOT_EXISTS("OPTION_NOT_EXISTS", "选项不存在"),
    OPTION_QUESTION_NOT_MATCH("OPTION_QUESTION_NOT_MATCH", "选项与题目不匹配"),
    CONTENT_OPTION_CODE_NOT_MATCH("CONTENT_OPTION_CODE_NOT_MATCH", "答案内容与选项编码不匹配"),
    REQUIRED_MISSING("REQUIRED_MISSING", "必填项缺失"),
    DUPLICATE_ANSWER("DUPLICATE_ANSWER", "重复答题数据");

    private final String code;
    private final String name;

    RuleViolationCode(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String code() {
        return code;
    }

    public String nameCn() {
        return name;
    }
}
