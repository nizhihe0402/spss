package com.example.spss.validator.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * 未通过校验的学生。
 */
public class FailedStudent {

    private Long studentId;
    private String studentName;
    private List<ViolationItem> violations = new ArrayList<ViolationItem>();

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public List<ViolationItem> getViolations() {
        return violations;
    }

    public void setViolations(List<ViolationItem> violations) {
        this.violations = violations;
    }
}
