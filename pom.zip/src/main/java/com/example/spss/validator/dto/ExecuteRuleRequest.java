package com.example.spss.validator.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ExecuteRuleRequest implements Serializable {

    private Long scriptId;
    private Long projectId;
    private Long tableId;
    private String year;
    private List<AnswerRow> rows = new ArrayList<AnswerRow>();

    public Long getScriptId() { return scriptId; }
    public void setScriptId(Long scriptId) { this.scriptId = scriptId; }

    public Long getProjectId() { return projectId; }
    public void setProjectId(Long projectId) { this.projectId = projectId; }

    public Long getTableId() { return tableId; }
    public void setTableId(Long tableId) { this.tableId = tableId; }

    public String getYear() { return year; }
    public void setYear(String year) { this.year = year; }

    public List<AnswerRow> getRows() { return rows; }
    public void setRows(List<AnswerRow> rows) { this.rows = rows; }
}
