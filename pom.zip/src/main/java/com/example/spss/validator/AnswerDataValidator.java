package com.example.spss.validator;

import com.example.spss.validator.dto.FailedStudent;
import com.example.spss.validator.dto.PassedStudent;
import com.example.spss.validator.dto.ValidateResult;
import com.example.spss.validator.dto.ViolationItem;
import com.example.spss.validator.meta.OptionMeta;
import com.example.spss.validator.meta.QuestionMeta;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 执行规则前的数据校验服务。
 *
 * 输出结果按学生分组：
 * 1. passedList：通过学生
 * 2. failedList：未通过学生 + 违反规则
 */
@Service
public class AnswerDataValidator {

    private final AnswerMetadataRepository metadataRepository;

    public AnswerDataValidator(AnswerMetadataRepository metadataRepository) {
        this.metadataRepository = metadataRepository;
    }

    public ValidateResult validate(List<AnswerDataRow> rows) {
        return validate(rows, null, null, null);
    }

    public ValidateResult validate(List<AnswerDataRow> rows,
                                   Long expectedTableId,
                                   Long expectedProjectId,
                                   String expectedYear) {
        ValidateResult result = new ValidateResult();
        if (rows == null) {
            rows = new ArrayList<AnswerDataRow>();
        }

        result.setTotalRows(rows.size());

        Set<Long> tableIds = new HashSet<Long>();
        Set<Long> projectIds = new HashSet<Long>();
        Set<Long> questionIds = new HashSet<Long>();
        Set<Long> optionIds = new HashSet<Long>();
        Set<Long> studentIds = new HashSet<Long>();

        for (AnswerDataRow row : rows) {
            if (row == null) {
                continue;
            }
            addIfNotNull(tableIds, row.getTableId());
            addIfNotNull(projectIds, row.getProjectId());
            addIfNotNull(questionIds, row.getQuestionId());
            addIfNotNull(optionIds, row.getOptionId());
            addIfNotNull(studentIds, row.getStudentId());
        }

        if (expectedTableId != null) {
            tableIds.add(expectedTableId);
        }
        if (expectedProjectId != null) {
            projectIds.add(expectedProjectId);
        }

        Set<Long> existingTableIds = metadataRepository.findExistingTableIds(tableIds);
        Set<Long> existingProjectIds = metadataRepository.findExistingProjectIds(projectIds);
        Map<Long, QuestionMeta> questionMap = metadataRepository.findQuestionsByIds(questionIds);
        Map<Long, OptionMeta> optionMap = metadataRepository.findOptionsByIds(optionIds);
        Map<Long, List<QuestionMeta>> requiredQuestionMap = metadataRepository.findRequiredQuestionsByTableIds(tableIds);
        Map<Long, String> studentNameMap = metadataRepository.findStudentNames(studentIds);

        Map<Long, List<AnswerDataRow>> rowsByStudent = groupByStudent(rows);
        Map<Long, List<ViolationItem>> violationsByStudent = new LinkedHashMap<Long, List<ViolationItem>>();

        // 行级校验。
        Map<String, List<AnswerDataRow>> duplicateMap = new LinkedHashMap<String, List<AnswerDataRow>>();
        for (AnswerDataRow row : rows) {
            if (row == null) {
                continue;
            }
            Long studentId = row.getStudentId();
            if (studentId == null) {
                studentId = Long.valueOf(-1L * safeLineNo(row));
            }

            List<ViolationItem> violations = getOrCreate(violationsByStudent, studentId);
            validateRow(row, expectedTableId, expectedProjectId, expectedYear,
                    existingTableIds, existingProjectIds, questionMap, optionMap, violations);

            String duplicateKey = buildDuplicateKey(row);
            List<AnswerDataRow> sameRows = duplicateMap.get(duplicateKey);
            if (sameRows == null) {
                sameRows = new ArrayList<AnswerDataRow>();
                duplicateMap.put(duplicateKey, sameRows);
            }
            sameRows.add(row);
        }

        // 重复数据校验。
        validateDuplicateRows(duplicateMap, violationsByStudent);

        // 学生维度必填项校验。
        validateRequiredQuestions(rowsByStudent, requiredQuestionMap, violationsByStudent, expectedTableId);

        // 组装通过 / 未通过。
        result.setStudentCount(rowsByStudent.size());
        for (Map.Entry<Long, List<AnswerDataRow>> entry : rowsByStudent.entrySet()) {
            Long studentId = entry.getKey();
            List<AnswerDataRow> studentRows = entry.getValue();
            String studentName = resolveStudentName(studentId, studentRows, studentNameMap);

            List<ViolationItem> violations = violationsByStudent.get(studentId);
            if (violations == null || violations.isEmpty()) {
                result.getPassedList().add(new PassedStudent(studentId, studentName));
            } else {
                FailedStudent failedStudent = new FailedStudent();
                failedStudent.setStudentId(studentId);
                failedStudent.setStudentName(studentName);
                for (ViolationItem item : violations) {
                    item.setStudentId(studentId);
                    item.setStudentName(studentName);
                }
                failedStudent.setViolations(violations);
                result.getFailedList().add(failedStudent);
            }
        }

        // 处理 student_id 缺失的伪学生分组。
        for (Map.Entry<Long, List<ViolationItem>> entry : violationsByStudent.entrySet()) {
            Long studentId = entry.getKey();
            if (studentId == null || studentId.longValue() >= 0L) {
                continue;
            }
            FailedStudent failedStudent = new FailedStudent();
            failedStudent.setStudentId(null);
            failedStudent.setStudentName("");
            failedStudent.setViolations(entry.getValue());
            result.getFailedList().add(failedStudent);
        }

        result.setPassedCount(result.getPassedList().size());
        result.setFailedCount(result.getFailedList().size());
        return result;
    }

    private void validateRow(AnswerDataRow row,
                             Long expectedTableId,
                             Long expectedProjectId,
                             String expectedYear,
                             Set<Long> existingTableIds,
                             Set<Long> existingProjectIds,
                             Map<Long, QuestionMeta> questionMap,
                             Map<Long, OptionMeta> optionMap,
                             List<ViolationItem> violations) {
        if (row.getStudentId() == null) {
            addViolation(violations, row, RuleViolationCode.STUDENT_ID_MISSING,
                    "student_id为空，无法归属到具体学生", "student_id");
        }

        if (row.getTableId() == null) {
            addViolation(violations, row, RuleViolationCode.TABLE_ID_MISSING,
                    "table_id为空", "table_id");
        } else {
            if (expectedTableId != null && !expectedTableId.equals(row.getTableId())) {
                addViolation(violations, row, RuleViolationCode.TABLE_NOT_MATCH,
                        "CSV table_id=" + row.getTableId() + " 与页面选择 table_id=" + expectedTableId + " 不一致", "table_id");
            }
            if (!existingTableIds.contains(row.getTableId())) {
                addViolation(violations, row, RuleViolationCode.TABLE_NOT_EXISTS,
                        "table_id=" + row.getTableId() + " 在 bus_table 中不存在或已删除", "table_id");
            }
        }

        if (row.getProjectId() == null) {
            addViolation(violations, row, RuleViolationCode.PROJECT_ID_MISSING,
                    "project_id为空", "project_id");
        } else {
            if (expectedProjectId != null && !expectedProjectId.equals(row.getProjectId())) {
                addViolation(violations, row, RuleViolationCode.PROJECT_NOT_MATCH,
                        "CSV project_id=" + row.getProjectId() + " 与页面 project_id=" + expectedProjectId + " 不一致", "project_id");
            }
            if (!existingProjectIds.contains(row.getProjectId())) {
                addViolation(violations, row, RuleViolationCode.PROJECT_NOT_EXISTS,
                        "project_id=" + row.getProjectId() + " 在 bus_project 中不存在或已删除", "project_id");
            }
        }

        if (isBlank(row.getYear())) {
            addViolation(violations, row, RuleViolationCode.YEAR_MISSING,
                    "year为空", "year");
        } else if (!isBlank(expectedYear) && !expectedYear.trim().equals(row.getYear().trim())) {
            addViolation(violations, row, RuleViolationCode.YEAR_NOT_MATCH,
                    "CSV year=" + row.getYear() + " 与页面 year=" + expectedYear + " 不一致", "year");
        }

        QuestionMeta questionMeta = null;
        if (row.getQuestionId() == null) {
            addViolation(violations, row, RuleViolationCode.QUESTION_ID_MISSING,
                    "question_id为空", "question_id");
        } else {
            questionMeta = questionMap.get(row.getQuestionId());
            if (questionMeta == null) {
                addViolation(violations, row, RuleViolationCode.QUESTION_NOT_EXISTS,
                        "question_id=" + row.getQuestionId() + " 在 bus_question 中不存在或已删除", "question_id");
            } else if (row.getTableId() != null && questionMeta.getTableId() != null
                    && !row.getTableId().equals(questionMeta.getTableId())) {
                addViolation(violations, row, RuleViolationCode.QUESTION_TABLE_NOT_MATCH,
                        "question_id=" + row.getQuestionId() + " 属于 table_id=" + questionMeta.getTableId()
                                + "，但当前数据 table_id=" + row.getTableId(), "question_id");
            }
        }

        if (row.getOptionId() != null) {
            OptionMeta optionMeta = optionMap.get(row.getOptionId());
            if (optionMeta == null) {
                addViolation(violations, row, RuleViolationCode.OPTION_NOT_EXISTS,
                        "option_id=" + row.getOptionId() + " 在 bus_option 中不存在或已删除", "option_id");
            } else {
                if (row.getQuestionId() != null && optionMeta.getQuestionId() != null
                        && !row.getQuestionId().equals(optionMeta.getQuestionId())) {
                    addViolation(violations, row, RuleViolationCode.OPTION_QUESTION_NOT_MATCH,
                            "option_id=" + row.getOptionId() + " 属于 question_id=" + optionMeta.getQuestionId()
                                    + "，但当前数据 question_id=" + row.getQuestionId(), "option_id");
                }

                // 单选/多选数据通常应保证 content 与 option.code 一致。
                if (!isBlank(row.getContent()) && !isBlank(optionMeta.getCode())
                        && !row.getContent().trim().equals(optionMeta.getCode().trim())) {
                    addViolation(violations, row, RuleViolationCode.CONTENT_OPTION_CODE_NOT_MATCH,
                            "content=" + row.getContent() + " 与 option_id=" + row.getOptionId()
                                    + " 的 code=" + optionMeta.getCode() + " 不一致", "content");
                }
            }
        }

        if (questionMeta != null && questionMeta.isRequired() && isBlank(row.getContent()) && row.getOptionId() == null) {
            addViolation(violations, row, RuleViolationCode.REQUIRED_MISSING,
                    "question_id=" + row.getQuestionId() + " 为必填题，但 content 为空且 option_id 为空", "content");
        }
    }

    private void validateDuplicateRows(Map<String, List<AnswerDataRow>> duplicateMap,
                                       Map<Long, List<ViolationItem>> violationsByStudent) {
        for (Map.Entry<String, List<AnswerDataRow>> entry : duplicateMap.entrySet()) {
            List<AnswerDataRow> sameRows = entry.getValue();
            if (sameRows == null || sameRows.size() <= 1) {
                continue;
            }
            for (AnswerDataRow row : sameRows) {
                Long studentKey = row.getStudentId();
                if (studentKey == null) {
                    studentKey = Long.valueOf(-1L * safeLineNo(row));
                }
                List<ViolationItem> violations = getOrCreate(violationsByStudent, studentKey);
                addViolation(violations, row, RuleViolationCode.DUPLICATE_ANSWER,
                        "同一学生同一题目存在重复数据，重复Key=" + entry.getKey(), "question_id");
            }
        }
    }

    private void validateRequiredQuestions(Map<Long, List<AnswerDataRow>> rowsByStudent,
                                           Map<Long, List<QuestionMeta>> requiredQuestionMap,
                                           Map<Long, List<ViolationItem>> violationsByStudent,
                                           Long expectedTableId) {
        if (rowsByStudent == null || rowsByStudent.isEmpty()) {
            return;
        }
        if (requiredQuestionMap == null || requiredQuestionMap.isEmpty()) {
            return;
        }

        for (Map.Entry<Long, List<AnswerDataRow>> entry : rowsByStudent.entrySet()) {
            Long studentId = entry.getKey();
            List<AnswerDataRow> rows = entry.getValue();
            if (rows == null || rows.isEmpty()) {
                continue;
            }

            Set<Long> studentTableIds = new HashSet<Long>();
            Map<Long, AnswerDataRow> answeredQuestionMap = new HashMap<Long, AnswerDataRow>();
            for (AnswerDataRow row : rows) {
                if (row.getTableId() != null) {
                    studentTableIds.add(row.getTableId());
                }
                if (row.getQuestionId() != null) {
                    answeredQuestionMap.put(row.getQuestionId(), row);
                }
            }

            if (expectedTableId != null) {
                studentTableIds.add(expectedTableId);
            }

            for (Long tableId : studentTableIds) {
                List<QuestionMeta> requiredQuestions = requiredQuestionMap.get(tableId);
                if (requiredQuestions == null || requiredQuestions.isEmpty()) {
                    continue;
                }
                for (QuestionMeta questionMeta : requiredQuestions) {
                    AnswerDataRow answeredRow = answeredQuestionMap.get(questionMeta.getQuestionId());
                    boolean missing = answeredRow == null
                            || (isBlank(answeredRow.getContent()) && answeredRow.getOptionId() == null);
                    if (!missing) {
                        continue;
                    }

                    AnswerDataRow baseRow = answeredRow == null ? rows.get(0) : answeredRow;
                    ViolationItem item = buildViolation(baseRow, RuleViolationCode.REQUIRED_MISSING,
                            "必填题缺失：question_id=" + questionMeta.getQuestionId()
                                    + "，table_id=" + questionMeta.getTableId()
                                    + "，题目=" + nullToEmpty(questionMeta.getContent()), "content");
                    item.setQuestionId(questionMeta.getQuestionId());
                    item.setTableId(questionMeta.getTableId());
                    getOrCreate(violationsByStudent, studentId).add(item);
                }
            }
        }
    }

    private Map<Long, List<AnswerDataRow>> groupByStudent(List<AnswerDataRow> rows) {
        Map<Long, List<AnswerDataRow>> map = new LinkedHashMap<Long, List<AnswerDataRow>>();
        for (AnswerDataRow row : rows) {
            if (row == null || row.getStudentId() == null) {
                continue;
            }
            List<AnswerDataRow> list = map.get(row.getStudentId());
            if (list == null) {
                list = new ArrayList<AnswerDataRow>();
                map.put(row.getStudentId(), list);
            }
            list.add(row);
        }
        return map;
    }

    private String resolveStudentName(Long studentId,
                                      List<AnswerDataRow> rows,
                                      Map<Long, String> studentNameMap) {
        if (rows != null) {
            for (AnswerDataRow row : rows) {
                if (row != null && !isBlank(row.getStudentName())) {
                    return row.getStudentName();
                }
            }
        }
        if (studentId != null && studentNameMap != null) {
            String name = studentNameMap.get(studentId);
            if (!isBlank(name)) {
                return name;
            }
        }
        return "";
    }

    private String buildDuplicateKey(AnswerDataRow row) {
        StringBuilder sb = new StringBuilder();
        sb.append(nullToEmpty(row.getStudentId())).append('|');
        sb.append(nullToEmpty(row.getProjectId())).append('|');
        sb.append(nullToEmpty(row.getTableId())).append('|');
        sb.append(nullToEmpty(row.getQuestionId())).append('|');
        sb.append(nullToEmpty(row.getOptionId())).append('|');
        sb.append(nullToEmpty(row.getYear()));
        return sb.toString();
    }

    private void addViolation(List<ViolationItem> violations,
                              AnswerDataRow row,
                              RuleViolationCode code,
                              String message,
                              String fieldName) {
        violations.add(buildViolation(row, code, message, fieldName));
    }

    private ViolationItem buildViolation(AnswerDataRow row,
                                         RuleViolationCode code,
                                         String message,
                                         String fieldName) {
        ViolationItem item = new ViolationItem();
        item.setRuleCode(code.code());
        item.setRuleName(code.nameCn());
        item.setMessage(message);
        item.setFieldName(fieldName);
        if (row != null) {
            item.setLineNo(row.getLineNo());
            item.setStudentId(row.getStudentId());
            item.setStudentName(row.getStudentName());
            item.setProjectId(row.getProjectId());
            item.setTableId(row.getTableId());
            item.setYear(row.getYear());
            item.setQuestionId(row.getQuestionId());
            item.setOptionId(row.getOptionId());
            item.setContent(row.getContent());
        }
        return item;
    }

    private List<ViolationItem> getOrCreate(Map<Long, List<ViolationItem>> map, Long key) {
        List<ViolationItem> list = map.get(key);
        if (list == null) {
            list = new ArrayList<ViolationItem>();
            map.put(key, list);
        }
        return list;
    }

    private int safeLineNo(AnswerDataRow row) {
        if (row == null || row.getLineNo() == null) {
            return 1;
        }
        return row.getLineNo().intValue() <= 0 ? 1 : row.getLineNo().intValue();
    }

    private void addIfNotNull(Collection<Long> collection, Long value) {
        if (value != null) {
            collection.add(value);
        }
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().length() == 0;
    }

    private String nullToEmpty(Object value) {
        return value == null ? "" : String.valueOf(value);
    }
}
