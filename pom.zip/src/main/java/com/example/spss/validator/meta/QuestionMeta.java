package com.example.spss.validator.meta;

/**
 * bus_question 元数据。
 */
public class QuestionMeta {

    private Long questionId;
    private Long tableId;
    private String content;
    private String bitian;
    private Long checktypeId;

    public Long getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Long questionId) {
        this.questionId = questionId;
    }

    public Long getTableId() {
        return tableId;
    }

    public void setTableId(Long tableId) {
        this.tableId = tableId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getBitian() {
        return bitian;
    }

    public void setBitian(String bitian) {
        this.bitian = bitian;
    }

    public Long getChecktypeId() {
        return checktypeId;
    }

    public void setChecktypeId(Long checktypeId) {
        this.checktypeId = checktypeId;
    }

    public boolean isRequired() {
        return "1".equals(bitian);
    }
}
