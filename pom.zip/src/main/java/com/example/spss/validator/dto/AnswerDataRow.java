package com.example.spss.validator.dto;

import java.util.Map;

/**
 * CSV / 上传数据解析后的答题行。
 *
 * 兼容字段：
 * student_id, studentName, student_name, 姓名
 * project_id, table_id, question_id, option_id, content, year
 */
public class AnswerDataRow {

    private Integer lineNo;
    private Long studentId;
    private String studentName;
    private Long projectId;
    private Long tableId;
    private Long checktypeId;
    private Long questionId;
    private Long optionId;
    private String content;
    private String year;
    private String dataType;
    private Map<String, String> rawData;

    public Integer getLineNo() {
        return lineNo;
    }

    public void setLineNo(Integer lineNo) {
        this.lineNo = lineNo;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getTableId() {
        return tableId;
    }

    public void setTableId(Long tableId) {
        this.tableId = tableId;
    }

    public Long getChecktypeId() {
        return checktypeId;
    }

    public void setChecktypeId(Long checktypeId) {
        this.checktypeId = checktypeId;
    }

    public Long getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Long questionId) {
        this.questionId = questionId;
    }

    public Long getOptionId() {
        return optionId;
    }

    public void setOptionId(Long optionId) {
        this.optionId = optionId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public Map<String, String> getRawData() {
        return rawData;
    }

    public void setRawData(Map<String, String> rawData) {
        this.rawData = rawData;
    }
}
