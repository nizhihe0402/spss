package com.example.spss.validator;

/**
 * 兼容类。
 *
 * 早期代码可能引用 com.example.spss.validator.AnswerDataRow。
 * 新 DTO 位于 com.example.spss.validator.dto.AnswerDataRow。
 * 为避免替换后出现导入不一致，本类继承 DTO。
 */
public class AnswerDataRow extends com.example.spss.validator.dto.AnswerDataRow {
}
