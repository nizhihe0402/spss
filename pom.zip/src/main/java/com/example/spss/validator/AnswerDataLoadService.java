package com.example.spss.validator;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 上传 CSV 数据读取服务。
 *
 * 注意：
 * 1. 保留 loadFromCsv(MultipartFile, Long, Long, String) 方法，匹配 Controller 调用。
 * 2. 不引入额外 CSV 依赖，兼容 Java 8。
 */
@Service
public class AnswerDataLoadService {

    @SuppressWarnings("rawtypes")
    public List loadFromCsv(MultipartFile file,
                                           Long tableId,
                                           Long projectId,
                                           String year) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("CSV文件不能为空");
        }

        try {
            return readCsv(file, tableId, projectId, year, StandardCharsets.UTF_8);
        } catch (RuntimeException utf8Exception) {
            // 兼容部分 Windows 导出的 GBK CSV。
            try {
                return readCsv(file, tableId, projectId, year, Charset.forName("GBK"));
            } catch (RuntimeException gbkException) {
                throw utf8Exception;
            }
        }
    }

    private List<AnswerDataRow> readCsv(MultipartFile file,
                                        Long defaultTableId,
                                        Long defaultProjectId,
                                        String defaultYear,
                                        Charset charset) {
        List<AnswerDataRow> rows = new ArrayList<AnswerDataRow>();
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new InputStreamReader(file.getInputStream(), charset));
            String headerLine = reader.readLine();
            if (headerLine == null || headerLine.trim().length() == 0) {
                return rows;
            }

            if (headerLine.startsWith("\uFEFF")) {
                headerLine = headerLine.substring(1);
            }

            List<String> headers = parseCsvLine(headerLine);
            String line;
            int lineNo = 1;

            while ((line = reader.readLine()) != null) {
                lineNo++;
                if (line.trim().length() == 0) {
                    continue;
                }

                List<String> values = parseCsvLine(line);
                Map<String, String> map = toMap(headers, values);
                AnswerDataRow row = toAnswerDataRow(map, lineNo, defaultTableId, defaultProjectId, defaultYear);
                rows.add(row);
            }

            return rows;
        } catch (Exception e) {
            throw new RuntimeException("读取CSV失败：" + e.getMessage(), e);
        } finally {
            closeQuietly(reader);
        }
    }

    private AnswerDataRow toAnswerDataRow(Map<String, String> map,
                                          int lineNo,
                                          Long defaultTableId,
                                          Long defaultProjectId,
                                          String defaultYear) {
        AnswerDataRow row = new AnswerDataRow();
        row.setLineNo(Integer.valueOf(lineNo));

        row.setStudentId(parseLong(firstNonBlank(
                get(map, "student_id"),
                get(map, "studentId"),
                get(map, "学生ID"),
                get(map, "学生id")
        )));

        row.setStudentName(firstNonBlank(
                get(map, "student_name"),
                get(map, "studentName"),
                get(map, "name"),
                get(map, "姓名"),
                get(map, "学生姓名")
        ));

        row.setProjectId(parseLongOrDefault(firstNonBlank(
                get(map, "project_id"),
                get(map, "projectId"),
                get(map, "项目ID"),
                get(map, "项目id")
        ), defaultProjectId));

        row.setTableId(parseLongOrDefault(firstNonBlank(
                get(map, "table_id"),
                get(map, "tableId"),
                get(map, "表ID"),
                get(map, "表id")
        ), defaultTableId));

        row.setChecktypeId(parseLong(firstNonBlank(
                get(map, "checktype_id"),
                get(map, "checktypeId"),
                get(map, "检查项ID"),
                get(map, "检查项id")
        )));

        row.setQuestionId(parseLong(firstNonBlank(
                get(map, "question_id"),
                get(map, "questionId"),
                get(map, "问题ID"),
                get(map, "问题id")
        )));

        row.setOptionId(parseLong(firstNonBlank(
                get(map, "option_id"),
                get(map, "optionId"),
                get(map, "选项ID"),
                get(map, "选项id")
        )));

        row.setContent(firstNonBlank(
                get(map, "content"),
                get(map, "answer"),
                get(map, "value"),
                get(map, "答案内容"),
                get(map, "内容")
        ));

        row.setYear(firstNonBlank(
                get(map, "year"),
                get(map, "年份"),
                defaultYear
        ));

        row.setDataType(firstNonBlank(
                get(map, "data_type"),
                get(map, "dataType")
        ));

        row.setRawData(map);
        return row;
    }

    private Map<String, String> toMap(List<String> headers, List<String> values) {
        Map<String, String> map = new LinkedHashMap<String, String>();
        if (headers == null) {
            return map;
        }

        for (int i = 0; i < headers.size(); i++) {
            String key = headers.get(i);
            String value = i < values.size() ? values.get(i) : "";
            if (key != null) {
                key = key.trim();
            }
            if (key == null || key.length() == 0) {
                continue;
            }
            map.put(key, value == null ? "" : value.trim());
        }
        return map;
    }

    /**
     * 简单 CSV 解析：支持英文逗号分隔、双引号包裹、双引号转义。
     */
    private List<String> parseCsvLine(String line) {
        List<String> result = new ArrayList<String>();
        if (line == null) {
            return result;
        }

        StringBuilder current = new StringBuilder();
        boolean inQuote = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (inQuote && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    current.append('"');
                    i++;
                } else {
                    inQuote = !inQuote;
                }
            } else if (c == ',' && !inQuote) {
                result.add(current.toString());
                current.setLength(0);
            } else {
                current.append(c);
            }
        }
        result.add(current.toString());
        return result;
    }

    private String get(Map<String, String> map, String key) {
        if (map == null || key == null) {
            return "";
        }
        String direct = map.get(key);
        if (direct != null) {
            return direct;
        }
        // 容忍表头大小写差异。
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (entry.getKey() != null && key.equalsIgnoreCase(entry.getKey().trim())) {
                return entry.getValue();
            }
        }
        return "";
    }

    private Long parseLong(String value) {
        if (value == null) {
            return null;
        }
        String s = value.trim();
        if (s.length() == 0) {
            return null;
        }
        try {
            if (s.indexOf('.') >= 0) {
                return Long.valueOf(Double.valueOf(s).longValue());
            }
            return Long.valueOf(s);
        } catch (Exception e) {
            return null;
        }
    }

    private Long parseLongOrDefault(String value, Long defaultValue) {
        Long parsed = parseLong(value);
        return parsed == null ? defaultValue : parsed;
    }

    private String firstNonBlank(String... values) {
        if (values == null) {
            return "";
        }
        for (String value : values) {
            if (value != null && value.trim().length() > 0) {
                return value.trim();
            }
        }
        return "";
    }

    private void closeQuietly(BufferedReader reader) {
        if (reader == null) {
            return;
        }
        try {
            reader.close();
        } catch (Exception ignored) {
        }
    }
}
