package com.example.spss.common;

/**
 * 简单统一返回对象。
 *
 * 说明：
 * 1. 如果你项目里已有 AjaxResult / R / Result，请在 Controller 中替换返回包装即可。
 * 2. 本类不依赖 Lombok，兼容 Java 8。
 */
public class ApiResponse<T> {

    private int code;
    private String msg;
    private T data;

    public ApiResponse() {
    }

    public ApiResponse(int code, String msg, T data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    public static <T> ApiResponse<T> success(T data) {
        return new ApiResponse<T>(0, "success", data);
    }

    public static <T> ApiResponse<T> success(String msg, T data) {
        return new ApiResponse<T>(0, msg, data);
    }

    public static <T> ApiResponse<T> error(String msg) {
        return new ApiResponse<T>(500, msg, null);
    }

    public static <T> ApiResponse<T> error(int code, String msg) {
        return new ApiResponse<T>(code, msg, null);
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
